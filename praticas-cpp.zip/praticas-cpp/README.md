# C++ | "C com Classes"

## Exercícios práticos e testes

Aqui irei postar apenas alguns exercícios feitos para prática, junto de estudos realizados ao decorrer do tempo.

### Práticas

**Exercícios práticos envolvendo:**

* Loopings (do while, while e for)
* Filas (estáticas e dinâmicas)
* Pilhas (estáticas e dinâmicas)
* Lista
* Struct
* Memória heap
* Switch case
* Estrutura de dados em geral
* Entre outros...